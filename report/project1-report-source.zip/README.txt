Compile project1-report.tex with Tectonic or pdfLaTeX.
All eight figure assets are included. Image paths alone differ from the repository source.
